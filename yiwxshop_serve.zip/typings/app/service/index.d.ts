// This file is created by egg-ts-helper@1.29.1
// Do not modify this file!!!!!!!!!

import 'egg';
type AnyClass = new (...args: any[]) => any;
type AnyFunc<T = any> = (...args: any[]) => T;
type CanExportFunc = AnyFunc<Promise<any>> | AnyFunc<IterableIterator<any>>;
type AutoInstanceType<T, U = T extends CanExportFunc ? T : T extends AnyFunc ? ReturnType<T> : T> = U extends AnyClass ? InstanceType<U> : U;
import ExportAdminUser = require('../../../app/service/adminUser');
import ExportCategory = require('../../../app/service/category');
import ExportGoods = require('../../../app/service/goods');
import ExportNormalUser = require('../../../app/service/normalUser');
import ExportOrder = require('../../../app/service/order');

declare module 'egg' {
  interface IService {
    adminUser: AutoInstanceType<typeof ExportAdminUser>;
    category: AutoInstanceType<typeof ExportCategory>;
    goods: AutoInstanceType<typeof ExportGoods>;
    normalUser: AutoInstanceType<typeof ExportNormalUser>;
    order: AutoInstanceType<typeof ExportOrder>;
  }
}
