'use strict';


module.exports = app => {
  const { router, controller } = app;
  router.get('/captcha',controller.util.imageCode);
  router.post('file','/app/v1/upload',controller.util.upLoad)
  //登录注册路由
  require("./router/account")(app)
  require("./router/userRouter")(app)
  require("./router/goodsRouter")(app)
  require("./router/categoryRouter")(app)
  require("./router/orderRouter")(app)
};
