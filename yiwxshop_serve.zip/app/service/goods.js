const Service = require('egg').Service;

class GoodsService extends Service {
    async getGoods(id){
        const { ctx } = this;
        //如果有id则为修改没有则为查询
        if(id){
            const goodsData = await ctx.model.Goods.findAll({
                where:{goods_id : id},
                include:[{
                    model:ctx.model.Category,
                    attributes:['sub_category_name']
                },{
                    model:ctx.model.Specifications,
                    attributes:['goods_id','specifications','pprice','maxprice','minprice']
                }]
            })
            return goodsData
        }
        const goodsData = await ctx.model.Goods.findAll({
            include:[{
                model:ctx.model.Category,
                attributes:['sub_category_name']
            },{
                model:ctx.model.Specifications,
                attributes:['goods_id','specifications','pprice','maxprice','minprice']
            }]
        })
        return goodsData
    }
    async addGood(fromData) {
        const {ctx} = this;
        //先查询改子分类的id,如果有该子分类就执行插入
        const hasCategory = await ctx.model.Category.findAll({
            where: {
                sub_category_name: fromData.sub_category
            },
        })
        //查询商品id是否已经存在
        const hasGoodsId = await ctx.model.Goods.findAll({
            where:{
                goods_id:fromData.goods_id
            }
        })
        if(hasCategory.length!==0 && hasGoodsId.length ===0) {
            try {
                const create = await ctx.model.Goods.create({
                    goods_id: fromData.goods_id,
                    title: fromData.title,
                    category_id:hasCategory[0].dataValues.category_id,
                    stock:fromData.stock,
                    description:fromData.description,
                    descrip_src:'',
                    type:fromData.type,
                    sale_time:new Date(),
                    good_pic:fromData.good_pic
                })
                return create
            } catch (e) {
                throw new Error(e)
            }
        }else if(hasGoodsId.length !== 0){
            console.log(hasGoodsId);
            throw new Error("商品id已经存在")
        }else{
            throw new Error("没有该分类")
        }
    }
    async altGoods(fromData){
        const {ctx} = this;
        //先查询改子分类的id,如果有该子分类就执行修改操作
        const hasCategory = await ctx.model.Category.findAll({
            where: {
                sub_category_name: fromData.sub_category
            },
        })
        try{
            const update = await ctx.model.Goods.update({
                title: fromData.title,
                category_id:hasCategory[0].dataValues.category_id,
                stock:fromData.stock,
                description:fromData.description,
                descrip_src:'',
                type:fromData.type,
                good_pic:fromData.good_pic
            },{
                where:{
                    goods_id:fromData.goods_id
                }
            })
            return update
        }catch (e) {
            throw Error(e)
        }
    }
    async delGoods(id){
        const { ctx } = this;
        const good = await ctx.model.Goods.findByPk(id);
        console.log(good);
        if(good){
            try{
              const result = await good.destroy()
              return result
            }catch(e){
                throw new Error(e)
            }
        }

    }
    async altSku(fromData){
        const { ctx } = this
        const hasSku =await ctx.model.Specifications.findAll({
            where:{
                goods_id:fromData.goods_id
            }
        })
        if(hasSku.length === 0){
            try{
                const sku = await ctx.model.Specifications.create({
                    pprice:{},
                    goods_id:fromData.goods_id,
                    specifications:fromData.specifications,
                    maxprice:fromData.maxprice,
                    minprice:fromData.minprice,
                })
                return sku
            }catch (e) {
                throw Error(e)
            }
        }else if(hasSku.length !== 0){
            try{
                const sku = await ctx.model.Specifications.update({
                    pprice:'',
                    goods_id:fromData.goods_id,
                    specifications:fromData.specifications,
                    maxprice:fromData.maxprice,
                    minprice:fromData.minprice,
                },{
                    where:{
                        goods_id:fromData.goods_id
                    }
                })
                return sku
            }catch (e) {
                throw Error(e)
            }
        }
    }
    async altpprice(fromData){
        const { ctx } = this
        const hasSku =await ctx.model.Specifications.findAll({
            where:{
                goods_id:fromData.goods_id
            }
        })
        if(hasSku.length !== 0){
            try{
                console.log(fromData.pprice);
                const skuprice = await ctx.model.Specifications.update({
                    pprice:fromData.pprice,
                },{
                    where:{
                        goods_id:fromData.goods_id
                    }
                })
                return skuprice
            }catch (e) {
                throw Error(e)
            }
        }else{
            throw new Error("该商品不存在")
        }
    }
}
module.exports = GoodsService