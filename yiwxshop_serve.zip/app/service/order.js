const Service = require('egg').Service

class orderService extends Service{
    async getOrder(){
        const { ctx } = this;
        const result =await ctx.model.Order.findAll({
            include:[{ model: ctx.model.User }]
        })
        return result
    }
    async altOrderState(){
        const { ctx } = this;
        const state = ctx.request.body.orderState
        const id = ctx.request.body.id
        console.log(id);
        const result =await ctx.model.Order.update({
            ship_status:state,
        },{
            where:{
                order_id:id
            }
        })
        console.log(result);
        return result
    }
}
module.exports = orderService