/* indent size: 2 */

module.exports = app => {
  const DataTypes = app.Sequelize;

  const Model = app.model.define('order', {
    order_id: {
      type: DataTypes.INTEGER(10).UNSIGNED.ZEROFILL,
      allowNull: false,
      primaryKey: true
    },
    user_id: {
      type: DataTypes.INTEGER(8).UNSIGNED.ZEROFILL,
      allowNull: false
    },
    no: {
      type: DataTypes.STRING(11),
      allowNull: true
    },
    address: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    total_price: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    paid_method: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    refund_status: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    refund_no: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    ship_status: {
      type: DataTypes.ENUM('1','2','3','4','5'),
      allowNull: true,
      defaultValue: '1'
    },
    reviewed: {
      type: DataTypes.INTEGER(1),
      allowNull: true
    },
    create_time: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    tableName: 'order'
  });

  Model.associate = function() {
    app.model.Order.belongsTo(app.model.User,{
      foreignKey:'user_id',
      targetKey:'id'
    })
  }

  return Model;
};
