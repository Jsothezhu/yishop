# yiwxshop



## 一个微信小商城，包括后端、前台和后台,后端使用eggjs,前台是uni-app和uview2.0,后台使用的是vue3.0和ant-design-vue



### 本地调试后端说明
先导入数据库，执行以下语句
```bash
$ npm i
$ npm run dev
```
###本地调试后台说明
```bash
$ npm i
$ npm run dev
```
###本地调试uni-app h5端说明
安装依赖，然后再网页端运行
```bash
$ npm i
```