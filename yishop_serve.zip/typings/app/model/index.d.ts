// This file is created by egg-ts-helper@1.29.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdminUser = require('../../../app/model/admin_user');
import ExportCart = require('../../../app/model/cart');
import ExportCategory = require('../../../app/model/category');
import ExportComment = require('../../../app/model/comment');
import ExportGoods = require('../../../app/model/goods');
import ExportOrder = require('../../../app/model/order');
import ExportOrderItem = require('../../../app/model/order_item');
import ExportOther = require('../../../app/model/other');
import ExportReceiver = require('../../../app/model/receiver');
import ExportSpecifications = require('../../../app/model/specifications');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    AdminUser: ReturnType<typeof ExportAdminUser>;
    Cart: ReturnType<typeof ExportCart>;
    Category: ReturnType<typeof ExportCategory>;
    Comment: ReturnType<typeof ExportComment>;
    Goods: ReturnType<typeof ExportGoods>;
    Order: ReturnType<typeof ExportOrder>;
    OrderItem: ReturnType<typeof ExportOrderItem>;
    Other: ReturnType<typeof ExportOther>;
    Receiver: ReturnType<typeof ExportReceiver>;
    Specifications: ReturnType<typeof ExportSpecifications>;
    User: ReturnType<typeof ExportUser>;
  }
}
