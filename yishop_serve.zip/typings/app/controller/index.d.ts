// This file is created by egg-ts-helper@1.29.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdminUser = require('../../../app/controller/adminUser');
import ExportCategory = require('../../../app/controller/category');
import ExportGoods = require('../../../app/controller/goods');
import ExportNormalUser = require('../../../app/controller/normalUser');
import ExportOrder = require('../../../app/controller/order');
import ExportUtil = require('../../../app/controller/util');
import ExportWxapp = require('../../../app/controller/wxapp');

declare module 'egg' {
  interface IController {
    adminUser: ExportAdminUser;
    category: ExportCategory;
    goods: ExportGoods;
    normalUser: ExportNormalUser;
    order: ExportOrder;
    util: ExportUtil;
    wxapp: ExportWxapp;
  }
}
