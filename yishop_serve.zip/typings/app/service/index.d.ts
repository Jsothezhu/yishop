// This file is created by egg-ts-helper@1.29.1
// Do not modify this file!!!!!!!!!

import 'egg';
type AnyClass = new (...args: any[]) => any;
type AnyFunc<T = any> = (...args: any[]) => T;
type CanExportFunc = AnyFunc<Promise<any>> | AnyFunc<IterableIterator<any>>;
type AutoInstanceType<T, U = T extends CanExportFunc ? T : T extends AnyFunc ? ReturnType<T> : T> = U extends AnyClass ? InstanceType<U> : U;
import ExportAdminUser = require('../../../app/service/adminUser');
import ExportCart = require('../../../app/service/cart');
import ExportCategory = require('../../../app/service/category');
import ExportGoods = require('../../../app/service/goods');
import ExportNormalUser = require('../../../app/service/normalUser');
import ExportOrder = require('../../../app/service/order');
import ExportReceiver = require('../../../app/service/receiver');

declare module 'egg' {
  interface IService {
    adminUser: AutoInstanceType<typeof ExportAdminUser>;
    cart: AutoInstanceType<typeof ExportCart>;
    category: AutoInstanceType<typeof ExportCategory>;
    goods: AutoInstanceType<typeof ExportGoods>;
    normalUser: AutoInstanceType<typeof ExportNormalUser>;
    order: AutoInstanceType<typeof ExportOrder>;
    receiver: AutoInstanceType<typeof ExportReceiver>;
  }
}
